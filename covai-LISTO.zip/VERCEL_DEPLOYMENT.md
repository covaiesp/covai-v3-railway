# COVAI Dashboard — Deploy en Vercel

## 🚀 Opción 1: Deploy automático con Vercel MCP (Recomendado)

```bash
# El proyecto está listo. Vercel MCP detectará automáticamente:
# - Framework: Next.js ✓
# - Build command: npm run build ✓
# - Start command: npm start ✓
```

## 📋 Requisitos previos

### 1. Supabase configurado
```
NEXT_PUBLIC_SUPABASE_URL=https://ptmfgyflyjkqjkzwrlnx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
```

### 2. Tablas en Supabase
- Ejecuta: SUPABASE_SETUP.sql en Supabase SQL Editor
- Crea: users, reservations, error_logs (opcional)
- Agrega RLS policies

### 3. Usuario demo
Email: admin@covai.es
Password: admin123

## 🔧 Variables de Entorno a Configurar en Vercel

En **Vercel Dashboard → Settings → Environment Variables**:

```
NEXT_PUBLIC_SUPABASE_URL = https://ptmfgyflyjkqjkzwrlnx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY = eyJhbGc...
```

## 📍 Dominio

Después del deploy:
1. Vercel → Settings → Domains
2. Agregar: www.covai.es
3. Copiar registros CNAME
4. Actualizar DNS en registrador
5. Esperar propagación (15-30 min)

## ✅ Verificación post-deploy

```bash
# Test en Vercel
https://covai-xxxxx.vercel.app/login

# Test con dominio (después de DNS)
https://www.covai.es/login

# Credenciales demo
Email: admin@covai.es
Pass: admin123
```

## 🔴 IMPORTANTE

En `components/DashboardHTML.jsx`:
- Función `getDashboardHTML()` contiene HTML PLACEHOLDER
- NECESITA ser reemplazado con HTML actual de `dashboard.html`

Sin esto, el dashboard restaurante estará vacío.

## 📦 Estructura lista para Vercel

```
covai-final-dashboard/
├── pages/
├── components/
├── lib/
├── public/
├── package.json ✓
├── next.config.js ✓
├── vercel.json ✓
├── .vercelignore ✓
└── .env.local.example
```

## 🎯 Timeline

| Fase | Tiempo |
|------|--------|
| Supabase setup | 30 min |
| npm install local | 5 min |
| Vercel deploy | 3 min |
| DNS propagación | 15-30 min |
| **TOTAL** | **~1 hora** |

## 🆘 Troubleshooting

### "Build failed"
- Verificar node_modules instalados localmente
- Ver logs en Vercel Dashboard
- Chequear scripts en package.json

### "Cannot find module 'supabase'"
- npm install ejecutado
- package.json tiene @supabase/supabase-js

### "Unauthorized" en login
- Variables SUPABASE correctas en Vercel Settings
- Usuario existe en Supabase Auth

---

**Generado**: 14 Mayo 2026
**Proyecto**: COVAI v3 Dashboard
**Estado**: ✅ Listo para Vercel
