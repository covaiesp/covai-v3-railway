#!/bin/bash

# Deploy a Vercel usando Vercel CLI
# Primero instala: npm i -g vercel

echo "🚀 Desplegando COVAI Dashboard a Vercel..."
echo ""

# Crear .vercelignore
cat > .vercelignore << 'IGNORE'
node_modules
.env.local
.next
.git
